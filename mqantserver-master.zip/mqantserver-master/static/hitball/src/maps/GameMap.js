"use strict";

/**
 * Created by love on 16/12/9.
 */
var extend = require('../utils/inherits.js');
module.exports = extend(Phaser.Tilemap, {});